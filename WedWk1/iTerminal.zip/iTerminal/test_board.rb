board = [
	[0,0],
	[1,2]
]

puts board [0,1]