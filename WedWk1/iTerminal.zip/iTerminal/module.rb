require 'terminfo'
require "./slide_parser"
require "./format"
require "pry"



array = Slide_Parser.new

pres1 = array.slide_to_array
binding.pry
pres1 = slides
slides = Screendata.new

puts slides.screendata

